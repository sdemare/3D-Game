# Shapespark Low-Poly Exterior Plants Kit
This folder contains the Shapespark low-poly exterior plants kit available 
from https://github.com/shapespark/shapespark-assets under the CC0
license.

The files have been converted to Godot assets.
